import React from 'react';
import HomeComponent from './Components/HomeComponent/HomeComponent';
import Preloader from './Components/HomeComponent/Preloader';
import LoginForm from './Components/HomeComponent/LoginForm';
import SignupForm from './Components/HomeComponent/SignupForm';
import ScrollToTop from './Components/ScrollToTop';
import Footer from './Components/Footer';
import SingleMovieComponent from './Components/SingleMovieComponent/SingleMovieComponent';
import MovieGridComponent from './Components/MovieGridComponent/MovieGridComponent';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";

function App() {
  return (
    <Router>
      <ScrollToTop>
        <Preloader />
        <LoginForm />
        <SignupForm />

        <Switch>
          <Route exact path="/">
            <HomeComponent />
          </Route>
          <Route path="/movielist">
            <MovieGridComponent />
          </Route>
          <Route path="/singlemovie/:id">
            <SingleMovieComponent />
          </Route>
        </Switch>
        <Footer />
      </ScrollToTop >
    </Router>
  );
}

export default App;

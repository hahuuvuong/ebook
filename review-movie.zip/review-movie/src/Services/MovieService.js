import { API, AUTH_INFOR } from '../config/apiconfig'
import { CATEGORYCONSTANT } from '../Constant/APICategory'
import axios from 'axios'

const MOVIE = 'movie';

export const getTrending = async () => {
    const MAIN_URL = API.MAIN_URL;
    const API_KEY = AUTH_INFOR.API_KEY;
    const TRENDING = CATEGORYCONSTANT.TRENDING;
    const response = await axios
        .get(`${MAIN_URL}/${TRENDING}/all/day?${API_KEY}`)
        .then(data => data)
        .catch(err => {
            console.log(err);
            return err;
        });
    return response;
}
export const getTopRated = async () => {
    const MAIN_URL = API.MAIN_URL;
    const API_KEY = AUTH_INFOR.API_KEY;
    const TOP_RATED = CATEGORYCONSTANT.TOP_RATED;
    const response = await axios
        .get(`${MAIN_URL}/${MOVIE}/${TOP_RATED}?${API_KEY}`)
        .then(data => data)
        .catch(err => {
            console.log(err);
            return err;
        });
    return response;
}

export const getUpComming = async () => {
    const MAIN_URL = API.MAIN_URL;
    const API_KEY = AUTH_INFOR.API_KEY;
    const COMING_SOON = CATEGORYCONSTANT.COMING_SOON;
    const response = await axios
        .get(`${MAIN_URL}/${MOVIE}/${COMING_SOON}?${API_KEY}`)
        .then(data => data)
        .catch(err => {
            console.log(err);
            return err;
        });
    return response;
}

export const getNowPlaying = async () => {
    const MAIN_URL = API.MAIN_URL;
    const API_KEY = AUTH_INFOR.API_KEY;
    const NOW_PLAYING = CATEGORYCONSTANT.NOW_PLAYING;
    const response = await axios
        .get(`${MAIN_URL}/${MOVIE}/${NOW_PLAYING}?${API_KEY}`)
        .then(data => data)
        .catch(err => {
            console.log(err);
            return err;
        });
    return response;
}
export const getDetailMovie = async ( idMovie) => {
    const MAIN_URL = API.MAIN_URL;
    const API_KEY = AUTH_INFOR.API_KEY;
    console.log('url ',`${MAIN_URL}/${MOVIE}/${idMovie}?${API_KEY}`);
    
    const response = await axios
        .get(`${MAIN_URL}/${MOVIE}/${idMovie}?${API_KEY}`)
        .then(data => data)
        .catch(err => {
            console.log(err);
            return err;
        });
    return response;
}
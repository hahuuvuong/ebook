import { API, AUTH_INFOR } from '../config/apiconfig'
import { CATEGORYCONSTANT } from '../Constant/APICategory'
import axios from 'axios'

const TV = 'tv'

export const getPopular = async () => {
    const MAIN_URL = API.MAIN_URL;
    const API_KEY = AUTH_INFOR.API_KEY;
    const POPULAR = CATEGORYCONSTANT.POPULAR;
    const response = await axios
        .get(`${MAIN_URL}/${TV}/${POPULAR}?${API_KEY}&language=en-US&page=1`)
        .then(data => data)
        .catch(err => {
            console.log(err);
            return err;
        });
    return response;
}

export const getTopRated = async () => {
    const MAIN_URL = API.MAIN_URL;
    const API_KEY = AUTH_INFOR.API_KEY;
    const TOP_RATED = CATEGORYCONSTANT.TOP_RATED;
    const response = await axios
        .get(`${MAIN_URL}/${TV}/${TOP_RATED}?${API_KEY}&language=en-US`)
        .then(data => data)
        .catch(err => {
            console.log(err);
            return err;
        });
    return response;
}

export const getOnTheAir = async () => {
    const MAIN_URL = API.MAIN_URL;
    const API_KEY = AUTH_INFOR.API_KEY;
    const ON_THE_AIR = CATEGORYCONSTANT.ON_THE_AIR;
    const response = await axios
        .get(`${MAIN_URL}/${TV}/${ON_THE_AIR}?${API_KEY}&language=en-US&page=1`)
        .then(data => data)
        .catch(err => {
            console.log(err);
            return err;
        });
    return response;
}

export const getAiringToday = async () => {
    const MAIN_URL = API.MAIN_URL;
    const API_KEY = AUTH_INFOR.API_KEY;
    const AIRING_TODAY = CATEGORYCONSTANT.AIRING_TODAY;
    const response = await axios
        .get(`${MAIN_URL}/${TV}/${AIRING_TODAY}?${API_KEY}&language=en-US&page=1`)
        .then(data => data)
        .catch(err => {
            console.log(err);
            return err;
        });
    return response;
}
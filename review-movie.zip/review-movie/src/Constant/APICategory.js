export const CATEGORYCONSTANT = {
    TRENDING: 'trending',
    TOP_RATED: 'top_rated',
    COMING_SOON: 'upcoming',
    LATEST: 'latest',
    NOW_PLAYING: 'now_playing',
    POPULAR: 'popular',
    ON_THE_AIR: 'on_the_air',
    AIRING_TODAY: 'airing_today',
}
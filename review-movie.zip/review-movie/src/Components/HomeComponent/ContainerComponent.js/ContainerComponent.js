import React, { useEffect, useState } from 'react';
import MovieItem from './MovieItem';
import * as  MovieService from '../../../Services/MovieService'
import * as  TvService from '../../../Services/TvShowService'
import { Card, Button, Row, Modal, CardDeck } from "react-bootstrap";

function ContainerComponent() {

    const [listMovie, setListMovie] = useState([]);
    const [listTopRated, setListTopRated] = useState([]);
    const [listUpComing, setListUpComing] = useState([]);
    const [listNowPlaying, setListNowPlaying] = useState([]);

    const [listTvPopular, setListTvPopular] = useState([]);
    const [listTvTopRated, setListTvTopRated] = useState([]);
    const [listTvOnTheAir, setListTvOnTheAir] = useState([]);
    const [listTvAiringToday, setListTvAiringToday] = useState([]);
    useEffect(() => {
        MovieService.getTrending()
            .then(res => setListMovie(res.data.results));

        MovieService.getTopRated()
            .then(res => setListTopRated(res.data.results));

        MovieService.getUpComming()
            .then(res => setListUpComing(res.data.results));

        MovieService.getNowPlaying()
            .then(res => setListNowPlaying(res.data.results));

    }, [])

    useEffect(() => {
        TvService.getPopular()
            .then(res => setListTvPopular(res.data.results));
        TvService.getTopRated()
            .then(res => setListTvTopRated(res.data.results));
        TvService.getOnTheAir()
            .then(res => setListTvOnTheAir(res.data.results));
        TvService.getAiringToday()
            .then(res => setListTvAiringToday(res.data.results));
    }, [])
    var tvTopRated = listTvTopRated.slice(0, 6);
    var tvPopular = listTvPopular.slice(0, 6);
    var tvOnTheAir = listTvOnTheAir.slice(0, 6);
    var tvAiringToday = listTvAiringToday.slice(0, 6);


    var moviesPopular = listMovie.slice(0, 6);
    var moviesCommingSoon = listUpComing.slice(0, 6);
    var moviesNowPlaying = listNowPlaying.slice(0, 6);
    var moviesTopRated = listTopRated.slice(0, 6);

    return (

        <div className="movie-items  full-width">
            <div className="row">
                <div className="col-md-12">
                    <div className="title-hd">
                        <h2>in theater</h2>
                        <a href="#" className="viewall">View a  ll <i className="ion-ios-arrow-right" /></a>
                    </div>
                    <div className="tabs">
                        <ul className="tab-links">
                            <li className="active"><a href="#tab1-h2">#Popular</a></li>
                            <li><a href="#tab2-h2"> #Coming soon</a></li>
                            <li><a href="#tab3-h2"> #Top rated</a></li>
                            <li><a href="#tab4-h2"> #Now playing</a></li>
                        </ul>
                        <div className="tab-content" style={{ marginTop: '35px' }}>
                            <div id="tab1-h2" className="tab active">
                                <div className="row">
                                    <div className="flex-list" >
                                        {moviesPopular.map(movie => <MovieItem poster_path={movie.poster_path} original_title={movie.original_title} vote_average={movie.vote_average} id={movie.id} />)}
                                    </div>
                                </div>
                            </div>
                            <div id="tab2-h2" className="tab">
                                <div className="row">
                                    <div className="flex-list">
                                        {moviesCommingSoon.map(movie => <MovieItem poster_path={movie.poster_path} original_title={movie.original_title} vote_average={movie.vote_average} id={movie.id} />)}
                                    </div>
                                </div>
                            </div>
                            <div id="tab3-h2" className="tab">
                                <div className="row">
                                    <div className="flex-list">
                                        {moviesTopRated.map(movie => <MovieItem poster_path={movie.poster_path} original_title={movie.original_title} vote_average={movie.vote_average} id={movie.id} />)}
                                    </div>
                                </div>
                            </div>
                            <div id="tab4-h2" className="tab">
                                <div className="row">
                                    <div className="flex-list">
                                        {moviesNowPlaying.map(movie => <MovieItem poster_path={movie.poster_path} original_title={movie.original_title} vote_average={movie.vote_average} id={movie.id} />)}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="title-hd">
                        <h2>on tv</h2>
                        <a href="#" className="viewall">View all <i className="ion-ios-arrow-right" /></a>
                    </div>
                    <div className="tabs">
                        <ul className="tab-links-2">
                            <li className="active"><a href="#tab21-h2">#Popular</a></li>
                            <li><a href="#tab22-h2"> #Top rated</a></li>
                            <li><a href="#tab23-h2"> #On the air</a></li>
                            <li><a href="#tab24-h2"> #Airing today</a></li>
                        </ul>
                        <div className="tab-content" style={{ marginTop: '35px' }}>
                            <div id="tab21-h2" className="tab active">
                                <div className="row">
                                    <div className="flex-list">
                                        {tvPopular.map(movie => <MovieItem poster_path={movie.poster_path} original_title={movie.original_title} vote_average={movie.vote_average} id={movie.id} />)}
                                    </div>
                                </div>
                            </div>
                            <div id="tab22-h2" className="tab">
                                <div className="row">
                                    <div className="flex-list">
                                        {tvTopRated.map(movie => <MovieItem poster_path={movie.poster_path} original_title={movie.original_title} vote_average={movie.vote_average} id={movie.id} />)}
                                    </div>
                                </div>
                            </div>
                            <div id="tab23-h2" className="tab">
                                <div className="row">
                                    <div className="flex-list">
                                        {tvOnTheAir.map(movie => <MovieItem poster_path={movie.poster_path} original_title={movie.original_title} vote_average={movie.vote_average} id={movie.id} />)}
                                    </div>
                                </div>
                            </div>
                            <div id="tab24-h2" className="tab">
                                <div className="row">
                                    <div className="flex-list">
                                        {tvAiringToday.map(movie => <MovieItem poster_path={movie.poster_path} original_title={movie.original_title} vote_average={movie.vote_average} id={movie.id} />)}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default ContainerComponent;
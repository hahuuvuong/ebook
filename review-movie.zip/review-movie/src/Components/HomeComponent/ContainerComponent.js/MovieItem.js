import React, { useEffect } from 'react';
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
} from "react-router-dom";


function MovieItem(props) {
    const imageURL = `https://image.tmdb.org/t/p/original/${props.poster_path}`;
    const original_title = props.original_title;
    const vote_average = props.vote_average;

    return (
        <div className="movie-item m-3" style={{ width: '375px' }}>
            <div className="mv-img">
                <img src={imageURL} alt="" />
            </div>
            <div className="hvr-inner">
                <Link to={{
                    pathname: `/singlemovie/${props.id}`
                }}> Read more <i className="ion-android-arrow-dropright" /> </Link>
            </div>
            <div className="title-in">
                <h6><a href="#">{original_title}</a></h6>
                <p><i className="ion-android-star" /><span>{vote_average}</span> /10</p>
            </div>
        </div>
    );
}

export default MovieItem;
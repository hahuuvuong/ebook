import React, { useEffect } from 'react';
import Slides from './Slides';
import ContainerComponent from './ContainerComponent.js/ContainerComponent';
import SingleMovieHeaderComponent from '../SingleMovieHeaderComponent';
import loadjs from 'loadjs'
function HomeComponent() {

    return (
        <div>
            <SingleMovieHeaderComponent />
            <Slides />
            <ContainerComponent />
        </div>
    );
}

export default HomeComponent;
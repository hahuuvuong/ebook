import React from 'react';
import Slide from './Slide';

function Slides(props) {
    return (
        <div className="slider sliderv2">
            <div className="container">
                <div className="row">
                    <div className="slider-single-item">
                        <Slide />
                        <Slide />
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Slides;
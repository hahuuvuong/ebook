import React from 'react';
import SingleMovieItem from './SingleMovieItem';
import SearchFormSideBar from './SearchFormSideBar';

function MovieGridContainerComponent(props) {
    return (
        <div className="page-single">
            <div className="container">
                <div className="row ipad-width">
                    <div className="col-md-8 col-sm-12 col-xs-12">
                        <div className="topbar-filter">
                            <p>Found <span>1,608 movies</span> in total</p>
                            <label>Sort by:</label>
                            <select>
                                <option value="popularity">Popularity Descending</option>
                                <option value="popularity">Popularity Ascending</option>
                                <option value="rating">Rating Descending</option>
                                <option value="rating">Rating Ascending</option>
                                <option value="date">Release date Descending</option>
                                <option value="date">Release date Ascending</option>
                            </select>
                            <a href="movielist.html" className="list"><i className="ion-ios-list-outline " /></a>
                            <a href="moviegrid.html" className="grid"><i className="ion-grid active" /></a>
                        </div>
                        <div className="flex-wrap-movielist">
                            <SingleMovieItem />
                            <SingleMovieItem />
                            <SingleMovieItem />
                            <SingleMovieItem />
                            <SingleMovieItem />
                            <SingleMovieItem />
                            <SingleMovieItem />
                            <SingleMovieItem />
                            <SingleMovieItem />
                            <SingleMovieItem />
                            <SingleMovieItem />
                            <SingleMovieItem />
                            <SingleMovieItem />
                            <SingleMovieItem />
                            <SingleMovieItem />
                            <SingleMovieItem />
                        </div>
                        <div className="topbar-filter">
                            <label>Movies per page:</label>
                            <select>
                                <option value="range">20 Movies</option>
                                <option value="saab">10 Movies</option>
                            </select>
                            <div className="pagination2">
                                <span>Page 1 of 2:</span>
                                <a className="active" href="#">1</a>
                                <a href="#">2</a>
                                <a href="#">3</a>
                                <a href="#">...</a>
                                <a href="#">78</a>
                                <a href="#">79</a>
                                <a href="#"><i className="ion-arrow-right-b" /></a>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 col-sm-12 col-xs-12">
                        <div className="sidebar">
                            <SearchFormSideBar />
                        </div>
                    </div>
                </div>
            </div>
        </div>

    );
}

export default MovieGridContainerComponent;
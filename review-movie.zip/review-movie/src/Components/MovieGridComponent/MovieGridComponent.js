import React from 'react';
import SingleMovieHeaderComponent from '../SingleMovieHeaderComponent';
import ClearFix1 from './ClearFix1';
import MovieGridContainerComponent from './MovieGridContainerComponent';

function MovieGridComponent(props) {
    return (
        <div>
            <SingleMovieHeaderComponent />
            <ClearFix1 />
            <MovieGridContainerComponent />
        </div>
    );
}

export default MovieGridComponent;
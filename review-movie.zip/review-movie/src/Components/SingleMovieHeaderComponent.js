import React from 'react';
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
} from "react-router-dom";
import HomeComponent from './HomeComponent/HomeComponent';

function SingleMovieHeaderComponent(props) {
    return (
        <header className="ht-header full-width-hd">
            <div className="row">
                <nav id="mainNav" className="navbar navbar-default navbar-custom">
                    {/* Brand and toggle get grouped for better mobile display */}
                    <div className="navbar-header logo">
                        <div className="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                            <span className="sr-only">Toggle navigation</span>
                            <div id="nav-icon1">
                                <span />
                                <span />
                                <span />
                            </div>
                        </div>
                        <Link to="/"><img className="logo" src="images/logo1.png" alt="" width={119} height={58} /></Link>
                    </div>
                    {/* Collect the nav links, forms, and other content for toggling */}
                    <div className="collapse navbar-collapse flex-parent" id="bs-example-navbar-collapse-1">
                        <ul className="nav navbar-nav flex-child-menu menu-left">
                            <li className="hidden">
                                <a href="#page-top" />
                            </li>
                            <li className="dropdown first">
                                {/* <a className="btn btn-default dropdown-toggle lv1" data-toggle="dropdown" data-hover="dropdown" href="/">
                                    Home
                                </a> */}
                                <Link to="/">Home</Link>
                                <Route exact path="/home" component={HomeComponent} />
                            </li>
                            <li className="dropdown first">
                                {/* <a className="btn btn-default dropdown-toggle lv1" data-toggle="dropdown" data-hover="dropdown">
                                    movies
                                </a> */}
                                <Link to="/movielist">List movie</Link>
                            </li>
                        </ul>
                        <ul className="nav navbar-nav flex-child-menu menu-right">
                            <li><a href="#">Help</a></li>
                            <li className="loginLink"><a href="#">LOG In</a></li>
                            <li className="btn signupLink"><a href="#">sign up</a></li>
                        </ul>
                    </div>
                    {/* /.navbar-collapse */}
                </nav>
                <div className="top-search">
                    <select>
                        <option value="united">TV show</option>
                        <option value="saab">Others</option>
                    </select>
                    <input type="text" placeholder="Search for a movie, TV Show or celebrity that you are looking for" />
                </div>
            </div>
        </header>
    );
}

export default SingleMovieHeaderComponent;
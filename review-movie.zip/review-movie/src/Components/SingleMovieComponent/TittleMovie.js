import React from 'react';

function TittleMovie(props) {

    return (
        <React.Fragment>
            <h1 className="bd-hd">{props.original_title} <span> {props.release_date}</span></h1>
            <div className="social-btn">
                <a href="#" className="parent-btn"><i className="ion-heart" /> Add to Favorite</a>
                <div className="hover-bnt">
                    <a href="#" className="parent-btn"><i className="ion-android-share-alt" />share</a>
                    <div className="hvr-item">
                        <a href="#" className="hvr-grow"><i className="ion-social-facebook" /></a>
                        <a href="#" className="hvr-grow"><i className="ion-social-twitter" /></a>
                        <a href="#" className="hvr-grow"><i className="ion-social-googleplus" /></a>
                        <a href="#" className="hvr-grow"><i className="ion-social-youtube" /></a>
                    </div>
                </div>
            </div>
            <div className="movie-rate">
                <div className="rate">
                    <i className="ion-android-star" />
                    <p><span>{props.vote_average}</span> /10<br />
                        <span className="rv">{props.vote_count} Reviews</span>
                    </p>
                </div>
            </div>
        </React.Fragment>
    );
}

export default TittleMovie;
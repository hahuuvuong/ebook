import React from 'react';

function ClearFix(props) {
    return (
        <div className="hero mv-single-hero">
            <div className="container">
                <div className="row">
                    <div className="col-md-12">
                        {/* <h1> movie listing - list</h1>
				<ul class="breadcumb">
					<li class="active"><a href="#">Home</a></li>
					<li> <span class="ion-ios-arrow-right"></span> movie listing</li>
				</ul> */}
                    </div>
                </div>
            </div>
        </div>

    );
}

export default ClearFix;
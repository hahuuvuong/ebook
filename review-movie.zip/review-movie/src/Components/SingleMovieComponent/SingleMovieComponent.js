import React from 'react';
import SingleMovieHeaderComponent from '../SingleMovieHeaderComponent';
import ClearFix from './ClearFix';
import SingleMovieContainerComponent from './SingleMovieContainerComponent';
import { useParams } from "react-router-dom";
function SingleMovieComponent(props) {

    let { id } = useParams()

    return (
        <div>
            <SingleMovieHeaderComponent />
            <ClearFix />
            <SingleMovieContainerComponent idMovie={id} />
        </div>
    );
}

export default SingleMovieComponent;
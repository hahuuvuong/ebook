import React, { useState, useEffect } from 'react';
import Poster from './Poster';
import TittleMovie from './TittleMovie';
import SingleMovieOverview from './SingleMovieOverview';
import * as TvService from '../../Services/MovieService';
function SingleMovieContainerComponent(props) {
    const idMovie = props.idMovie;

    const [movieDetail, setMovieDetail] = useState({});
    useEffect(() => {
        TvService.getDetailMovie(idMovie)
            .then((res) => setMovieDetail(res.data));
    }, []);

    return (
        <div className="page-single movie-single movie_single">
            <div className="container">
                <div className="row ipad-width2">
                    <Poster imgPoster={movieDetail.poster_path} />
                    <div className="col-md-8 col-sm-12 col-xs-12">
                        <div className="movie-single-ct main-content">
                            <TittleMovie
                                original_title={movieDetail.original_title}
                                release_date={movieDetail.release_date}
                                vote_average={movieDetail.vote_average}
                                vote_count={movieDetail.vote_count} />
                            <div className="movie-tabs">
                                <div className="tabs">
                                    <ul className="tab-links tabs-mv">
                                        <li className="active"><a href="#overview">Overview</a></li>
                                    </ul>
                                    <div className="tab-content">
                                        <div id="overview" className="tab active">
                                            <SingleMovieOverview 
                                            overview={movieDetail.overview}
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    );
}

export default SingleMovieContainerComponent;
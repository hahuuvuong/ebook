import React from 'react';

function SingleMovieOverview(props) {
    return (
            <div className="row">
                <div className="col-md-8 col-sm-12 col-xs-12">
                    <p>{props.overview}</p>
                    <div className="title-hd-sm">
                        <h4>Videos &amp; Photos</h4>
                        <a className="time">All 5 Videos &amp; 245 Photos <i className="ion-ios-arrow-right" /></a>
                    </div>
                    <div className="mvsingle-item ov-item">
                        <a className="img-lightbox" data-fancybox-group="gallery" href="images/uploads/image11.jpg"><img src="images/uploads/image1.jpg" alt="" /></a>
                        <a className="img-lightbox" data-fancybox-group="gallery" href="images/uploads/image21.jpg"><img src="images/uploads/image2.jpg" alt="" /></a>
                        <a className="img-lightbox" data-fancybox-group="gallery" href="images/uploads/image31.jpg"><img src="images/uploads/image3.jpg" alt="" /></a>
                        <div className="vd-it">
                            <img className="vd-img" src="images/uploads/image4.jpg" alt="" />
                            <a className="fancybox-media hvr-grow" href="https://www.youtube.com/embed/o-0hcF97wy0"><img src="images/uploads/play-vd.png" alt="" /></a>
                        </div>
                    </div>
                    <div className="title-hd-sm">
                        <h4>cast</h4>
                        <a className="time">Full Cast &amp; Crew  <i className="ion-ios-arrow-right" /></a>
                    </div>
                    {/* movie cast */}
                    <div className="mvcast-item">
                        <div className="cast-it">
                            <div className="cast-left">
                                <img src="images/uploads/cast1.jpg" alt="" />
                                <a>Robert Downey Jr.</a>
                            </div>
                            <p>...  Robert Downey Jr.</p>
                        </div>
                        <div className="cast-it">
                            <div className="cast-left">
                                <img src="images/uploads/cast2.jpg" alt="" />
                                <a >Chris Hemsworth</a>
                            </div>
                            <p>...  Thor</p>
                        </div>
                        <div className="cast-it">
                            <div className="cast-left">
                                <img src="images/uploads/cast3.jpg" alt="" />
                                <a >Mark Ruffalo</a>
                            </div>
                            <p>...  Bruce Banner/ Hulk</p>
                        </div>
                        <div className="cast-it">
                            <div className="cast-left">
                                <img src="images/uploads/cast4.jpg" alt="" />
                                <a >Chris Evans</a>
                            </div>
                            <p>...  Steve Rogers/ Captain America</p>
                        </div>
                        <div className="cast-it">
                            <div className="cast-left">
                                <img src="images/uploads/cast5.jpg" alt="" />
                                <a >Scarlett Johansson</a>
                            </div>
                            <p>...  Natasha Romanoff/ Black Widow</p>
                        </div>
                        <div className="cast-it">
                            <div className="cast-left">
                                <img src="images/uploads/cast6.jpg" alt="" />
                                <a>Jeremy Renner</a>
                            </div>
                            <p>...  Clint Barton/ Hawkeye</p>
                        </div>
                        <div className="cast-it">
                            <div className="cast-left">
                                <img src="images/uploads/cast7.jpg" alt="" />
                                <a >James Spader</a>
                            </div>
                            <p>...  Ultron</p>
                        </div>
                        <div className="cast-it">
                            <div className="cast-left">
                                <img src="images/uploads/cast9.jpg" alt="" />
                                <a >Don Cheadle</a>
                            </div>
                            <p>...  James Rhodes/ War Machine</p>
                        </div>
                    </div>
                    <div className="title-hd-sm">
                        <h4>User reviews</h4>
                        <a className="time">See All 56 Reviews <i className="ion-ios-arrow-right" /></a>
                    </div>
                    {/* movie user review */}
                    <div className="mv-user-review-item">
                        <h3>Best Marvel movie in my opinion</h3>
                        <div className="no-star">
                            <i className="ion-android-star" />
                            <i className="ion-android-star" />
                            <i className="ion-android-star" />
                            <i className="ion-android-star" />
                            <i className="ion-android-star" />
                            <i className="ion-android-star" />
                            <i className="ion-android-star" />
                            <i className="ion-android-star" />
                            <i className="ion-android-star" />
                            <i className="ion-android-star last" />
                        </div>
                        <p className="time">
                            17 December 2016 by <a > hawaiipierson</a>
                        </p>
                        <p>This is by far one of my favorite movies from the MCU. The introduction of new Characters both good and bad also makes the movie more exciting. giving the characters more of a back story can also help audiences relate more to different characters better, and it connects a bond between the audience and actors or characters. Having seen the movie three times does not bother me here as it is as thrilling and exciting every time I am watching it. In other words, the movie is by far better than previous movies (and I do love everything Marvel), the plotting is splendid (they really do out do themselves in each film, there are no problems watching it more than once.</p>
                    </div>
                </div>
                <div className="col-md-4 col-xs-12 col-sm-12">
                    <div className="sb-it">
                        <h6>Director: </h6>
                        <p><a>Joss Whedon</a></p>
                    </div>
                    <div className="sb-it">
                        <h6>Writer: </h6>
                        <p><a  >Joss Whedon,</a> <a  >Stan Lee</a></p>
                    </div>
                    <div className="sb-it">
                        <h6>Stars: </h6>
                        <p><a  >Robert Downey Jr,</a> <a  >Chris Evans,</a> <a  >Mark Ruffalo,</a><a  > Scarlett Johansson</a></p>
                    </div>
                    <div className="sb-it">
                        <h6>Genres:</h6>
                        <p><a  >Action, </a> <a  > Sci-Fi,</a> <a  >Adventure</a></p>
                    </div>
                    <div className="sb-it">
                        <h6>Release Date:</h6>
                        <p>May 1, 2015 (U.S.A)</p>
                    </div>
                    <div className="sb-it">
                        <h6>Run Time:</h6>
                        <p>141 min</p>
                    </div>
                    <div className="sb-it">
                        <h6>MMPA Rating:</h6>
                        <p>PG-13</p>
                    </div>
                    <div className="sb-it">
                        <h6>Plot Keywords:</h6>
                        <p className="tags">
                            <span className="time"><a  >superhero</a></span>
                            <span className="time"><a  >marvel universe</a></span>
                            <span className="time"><a  >comic</a></span>
                            <span className="time"><a  >blockbuster</a></span>
                            <span className="time"><a  >final battle</a></span>
                        </p>
                    </div>
                    <div className="ads">
                        <img src="images/uploads/ads1.png" alt="" />
                    </div>
                </div>
            </div>
    );
}

export default SingleMovieOverview;
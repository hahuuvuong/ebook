export const API = {
    MAIN_URL: "https://api.themoviedb.org/3"
}

export const AUTH_INFOR = {
    API_KEY: "api_key=9dd67d13e3f6f1c4d6db5c08a1a93069"
}
